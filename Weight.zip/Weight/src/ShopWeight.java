

public class ShopWeight {
	
	public int rank;
	public ShopWeight(int rank, String desc) {
		super();
		this.rank = rank;
		this.desc = desc;
	}
	public String desc;

}
