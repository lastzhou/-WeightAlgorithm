import java.util.ArrayList;
import java.util.List;

public class Weight<E> {
	List<WeightData<E>> list=new ArrayList();
	
	public void addData(List<WeightData<E>> listDatas) {
		if (listDatas!=null) {
			list.addAll(listDatas);
		}
	}
	
	public void add(WeightData<E> weightData) {
		list.add(weightData);
	}
	
	public E findWeight(int value) {
		int index=list.size()/2;
		WeightData<E> middleData=	list.get(index);
		int findData=value;
		E weight=null;
		do {
			
			//遵守 zhubi you kai
			while (findData< middleData.min) {
				index--;
				if (index>=0) {
					middleData=list.get(index);
				}else {
					break;
				}
			}
			
			
			while (findData>middleData.max) {
				index++;
				if (index<list.size()) {
					middleData=list.get(index);
				}else {
					break;
				}
				
			}
			
				weight= middleData.weight;
				break;
			
		} while (true);
		
		return weight;
		
	}
	
	public static class WeightData <E>{
		
		public int min;
		public WeightData(int min, int max, E weight) {
			super();
			this.min = min;
			this.max = max;
			this.weight = weight;
		}
		public int max;
		public E weight;
		

	}
	
	
}
