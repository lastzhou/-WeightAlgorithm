
public class WeightData <E>{
	
	public int min;
	public WeightData(int min, int max, E weight) {
		super();
		this.min = min;
		this.max = max;
		this.weight = weight;
	}
	public int max;
	public E weight;
	

}
