import java.util.ArrayList;
import java.util.List;
@SuppressWarnings("unchecked")
public class Main {
	
	@SuppressWarnings("rawtypes")
	public static void main(String[] args) {
		
		Weight weight=new Weight<ShopWeight>();
		Weight.WeightData<ShopWeight> weight1= new Weight.WeightData(0,1000,new ShopWeight(3, "d"));
		weight.add(weight1);
		weight.add(new Weight.WeightData(1000,3000,new ShopWeight(6, "青铜")));
		weight.add(new Weight.WeightData(3000,6000,new ShopWeight(8, "白银")));
		weight.add(new Weight.WeightData(6000,10000,new ShopWeight(9, "黄金")));
		weight.add(new Weight.WeightData(10000,15000,new ShopWeight(45, "王者")));
		ShopWeight fWeight=  (ShopWeight) weight.findWeight(1000);
		System.out.println(fWeight.toString());
			
	}

}
